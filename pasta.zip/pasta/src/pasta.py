# A GUI tool to store multiple text strings and simulate typing said strings upon pressing hot keys.
# Ken Chen 2020

import tkinter as tk
from tkinter import ttk
import keyboard
#import cv2
#import numpy as np
#from PIL import ImageGrab

def store_values(entries):
    # After pressing Win + L to lock screen, the program gets the events that they are pressed, but not the events of them being released.
    # The folloing code is to ensure such keys are released if found to be pressed. Otherwise it blocks all hotkeys.
    for pressed_key in keyboard.stash_state():
        keyboard.send(pressed_key, do_press=False, do_release=True)
    for i in range(0,10):
        values[i] = entries[i].get()

def toggle(entries):
    if entries[0]["show"] == "":
        for i in range(0,10):
            entries[i]["show"] = "*"
    else:
        for i in range(0,10):
            entries[i]["show"] = ""

### This is the function to recognize the 8 digit RSA token shown on screen.
##def get_token():
##    # Upper left hand corner is the detection area.
##    area = (0, 0, 1000, 600)
##    # Take screen shot of said area
##    screenshot = ImageGrab.grab(area)
##    # Convert it to an array for opencv, subsequently to grayscale
##    img = np.array(screenshot)
##    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
##
##    # As it matches the individual image of 0 to 9,
##    # token_dict stores the x axis position value and the digit found
##    token_dict = {}
##    for i in range(10):
##        template = cv2.imread("images/"+str(i)+".png", cv2.IMREAD_GRAYSCALE)
##        result = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
##        loc = np.where(result >= 0.9)
##        for pt in zip(*loc):
##            token_dict[pt[1]] = str(i)
##
##    # Sort token_dict by the position value
##    sorted_token_dict = sorted(token_dict.items(), key = lambda t : t[0])
##
##    
##    # Concatenate the sorted digit values to get the final result
##    final_token = ""
##    for position, digit in sorted_token_dict:
##        final_token = final_token + str(digit)
##
##    return(final_token)

def clear_text(textbox):
    textbox.delete("1.0", "end")
    textbox.get_content()

def store_text(textbox):
    textbox.get_content()

def on_closing():
    remove_hotkeys()
    values = []
    root.destroy()

# Registering hotkeys
def register_hotkeys():
    keyboard.add_hotkey('ctrl+shift+0', lambda: keyboard.write(values[0]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+1', lambda: keyboard.write(values[1]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+2', lambda: keyboard.write(values[2]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+3', lambda: keyboard.write(values[3]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+4', lambda: keyboard.write(values[4]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+5', lambda: keyboard.write(values[5]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+6', lambda: keyboard.write(values[6]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+7', lambda: keyboard.write(values[7]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+8', lambda: keyboard.write(values[8]), suppress=True)
    keyboard.add_hotkey('ctrl+shift+9', lambda: keyboard.write(values[9]), suppress=True)
    #keyboard.add_hotkey('ctrl+shift+k', lambda: keyboard.write(values[10]+get_token()), suppress=True)
    keyboard.add_hotkey('ctrl+shift+;', lambda: keyboard.write(textbox2.get_current_line()), suppress=True)
    keyboard.add_hotkey('ctrl+shift+\'', lambda: keyboard.write(textbox3.get_current_line()), suppress=True)
    
def remove_hotkeys():
    keyboard.remove_hotkey('ctrl+shift+0')
    keyboard.remove_hotkey('ctrl+shift+1')
    keyboard.remove_hotkey('ctrl+shift+2')
    keyboard.remove_hotkey('ctrl+shift+3')
    keyboard.remove_hotkey('ctrl+shift+4')
    keyboard.remove_hotkey('ctrl+shift+5')
    keyboard.remove_hotkey('ctrl+shift+6')
    keyboard.remove_hotkey('ctrl+shift+7')
    keyboard.remove_hotkey('ctrl+shift+8')
    keyboard.remove_hotkey('ctrl+shift+9')
    #keyboard.remove_hotkey('ctrl+shift+k')
    keyboard.remove_hotkey('ctrl+shift+;')
    keyboard.remove_hotkey('ctrl+shift+\'')
    

# This class extends tkinter's standard textbox.
class CustomText(tk.Text):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.current_line_number = 0
        self.content_list = []

    # Get the number of lines currently in textbox, at least 1.
    def get_total_lines(self):
        return(int(self.index('end-1c').split('.')[0]))

    # Store the content of the textbox in a list, with each line being an item.
    def get_content(self):
        self.content_list = []
        for i in range(1, self.get_total_lines()+1):
            self.content_list.append(self.get(str(i)+'.0', str(i)+'.end'))
            i = i + 1
        self.current_line_number =  0

    # Return the current line, with current_line_number being the counter.
    def get_current_line(self):
        if self.content_list:
            current_line = self.content_list[self.current_line_number]
            self.current_line_number = self.current_line_number + 1
            # Reset counter if it reaches the end.
            if self.current_line_number == self.get_total_lines():
                self.current_line_number = 0
            return(current_line)
        else:
            return('')


# Global variable declarations
try:
    with open("init.txt") as ifile:
        values=[v.rstrip() for v in ifile.readlines()[0:10]]
except Exception:
    values = ['','','','','','','','','','','']
finally:
    if len(values) != 10:
        values = ['','','','','','','','','','','']

# Root window definitions
root = tk.Tk()
root.geometry("250x380+50+250")
root.resizable(False, False)
root.title("Pasta")
root.protocol("WM_DELETE_WINDOW", on_closing)

# Tab style layout
nb = ttk.Notebook(root)
nb.pack()

# Widget placement of frame 1
frame = tk.Frame(nb)

for i in range(0,10):
    label = tk.Label(frame, text="Ctrl + Shift "+ str(i))
    label.grid(row=i, column=0)

entries = []
for i in range(0,10):
    entry_text = tk.StringVar()
    entry = tk.Entry(frame, textvariable=entry_text)
    entry_text.set(values[i])
    entry.grid(row=i, column=1, padx=2, pady=2)
    entries.append(entry)

##tokenlb1 = tk.Label(frame, text="Put RSA soft token on upper left corner")
##tokenlb1.grid(row=10, column=0, columnspan=2)
##tokenlb2 = tk.Label(frame, text="Input 8-digit PIN below")
##tokenlb2.grid(row=11, column=0, columnspan=2)
##tokenlb3 = tk.Label(frame, text="Ctrl + Shift +k")
##tokenlb3.grid(row=12, column=0)

##token_entry_text = tk.StringVar()
##token_entry = tk.Entry(frame, textvariable=token_entry_text)
##token_entry_text.set(values[10])
##token_entry.grid(row=12, column=1, padx=2, pady=2)
##entries.append(token_entry)

toggle_button = tk.Button(frame, text="show/hide", command=lambda: toggle(entries))
##toggle_button.grid(row=13, column=0, padx=2, pady=2)
toggle_button.grid(row=10, column=0, padx=2, pady=2)

apply_button = tk.Button(frame, text="apply", command=lambda: store_values(entries))
##apply_button.grid(row=13, column=1, padx=2, pady=2)
apply_button.grid(row=10, column=1, padx=2, pady=2)

#Widget placement of Frame 2
frame2 = tk.Frame(nb)

label2 = tk.Label(frame2, text='Ctrl + Shift + ; (semi-colon)')
label2.grid(row=0, column=0, columnspan=2)

textbox2 = CustomText(frame2, height=16, width=26, wrap="none")
textbox2.grid(row=1, column=0, columnspan=2)

vertical_scroll2 = tk.Scrollbar(frame2, orient="vertical", command=textbox2.yview)
horizontal_scroll2 = tk.Scrollbar(frame2, orient="horizontal", command=textbox2.xview)
vertical_scroll2.grid(row=1, column=2, sticky="NSW")
horizontal_scroll2.grid(row=2, column=0, columnspan=2, sticky="EWN")

clear_button2 = tk.Button(frame2, text="clear", command=lambda: clear_text(textbox2))
clear_button2.grid(row=3, column=0)

apply_button2 = tk.Button(frame2, text="apply", command=lambda: store_text(textbox2))
apply_button2.grid(row=3, column=1)

# Widget placement of Frame 3
frame3 = tk.Frame(nb)

label3 = tk.Label(frame3, text='Ctrl + Shift + \' (single quote)')
label3.grid(row=0, column=0, columnspan=2)

textbox3 = CustomText(frame3, height=16, width=26, wrap="none")
textbox3.grid(row=1, column=0, columnspan=2)

vertical_scroll3 = tk.Scrollbar(frame3, orient="vertical", command=textbox3.yview)
horizontal_scroll3 = tk.Scrollbar(frame3, orient="horizontal", command=textbox3.xview)
vertical_scroll3.grid(row=1, column=2, sticky="NSW")
horizontal_scroll3.grid(row=2, column=0, columnspan=2, sticky="EWN")

clear_button3 = tk.Button(frame3, text="clear", command=lambda: clear_text(textbox3))
clear_button3.grid(row=3, column=0)

apply_button3 = tk.Button(frame3, text="apply", command=lambda: store_text(textbox3))
apply_button3.grid(row=3, column=1)

# Add frames to tabs
nb.add(frame, text="Single-line")
nb.add(frame2, text="Multi-line")
nb.add(frame3, text="Multi-line")

# Registering hotkeys
register_hotkeys()

root.mainloop()







        
    


    








