#!/bin/sh
# This script is for creating any weblogic domain 
# The following files must be present in the same directory
# wls_domain_setup.sh
# wls_domain_creator.py
# domain.properties
# ctrlAdm.py.template
# ctrlMgd.py.template
# nmGenBootStartupProps.py
# This script requires values from domain.properties

check_prereq() {
	if [[ -f $BASEDIR/wls_domain_creator.py && -f $BASEDIR/domain.properties && -f $BASEDIR/ctrlAdm.py.template && -f $BASEDIR/ctrlMgd.py.template && -f $BASEDIR/nmGenBootStartupProps.py ]]; then
		echo "All expected files are present, proceeding..."
	else
		echo "Could not find one or more of pre-req files, exiting"
		exit 2
	fi
}

source_props() {
	. ./domain.properties
}

wls_domain_creator() {
	echo "Running wls_domain_creator.py"
	$mwhome/common/bin/wlst.sh wls_domain_creator.py
}

prepare_nm_config() {
	# Backup original nodemanager.properties
	echo "Backing up original nodemanager.properties"
	cp -p ${domainroot}/${domain_name}/nodemanager/nodemanager.properties ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_`date +%Y%m%d%H%M%S`
	
	#Prepare a nodemanager.properties for each machine, if multiple machines
	echo "Preparing a nodemanager.properties for each machine"
	for machine in `echo $machines | sed 's/,/ /g'`
	do
		machine_name=${machine}_Name
		machine_nm_secure=${machine}_nm_secure
		machine_nm_address=${machine}_nm_address
		machine_nm_port=${machine}_nm_port
		machine_keystore=${machine}_KeyStore
		machine_keystorepw=${machine}_KeyStorePW
		machine_truststore=${machine}_TrustStore
		machine_truststorepw=${machine}_TrustStorePW
		machine_privatealias=${machine}_PrivateKeyAlias
		machine_privatepw=${machine}_PrivateKeyPW
		
		# Make a copy of nodemanager.properties for each machine
		cp -p ${domainroot}/${domain_name}/nodemanager/nodemanager.properties ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		# Update some of the entries in nodemanager.properties based on values in domain.properties
		sed -i -n -e '/^SecureListener=/!p' -e '$aSecureListener='"${!machine_nm_secure}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^ListenAddress=/!p' -e '$aListenAddress='"${!machine_nm_address}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^ListenPort=/!p' -e '$aListenPort='"${!machine_nm_port}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^KeyStores=/!p' -e '$aKeyStores='CustomIdentityAndCustomTrust ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomIdentityKeystoreType=/!p' -e '$aCustomIdentityKeystoreType='jks ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomIdentityKeyStoreFileName=/!p' -e '$aCustomIdentityKeyStoreFileName='"${!machine_keystore}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomIdentityKeyStorePassPhrase=/!p' -e '$aCustomIdentityKeyStorePassPhrase='"${!machine_keystorepw}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomIdentityAlias=/!p' -e '$aCustomIdentityAlias='"${!machine_privatealias}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomIdentityPrivateKeyPassPhrase=/!p' -e '$aCustomIdentityPrivateKeyPassPhrase='"${!machine_privatepw}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomTrustKeystoreType=/!p' -e '$aCustomTrustKeystoreType='jks ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomTrustKeyStoreFileName=/!p' -e '$aCustomTrustKeyStoreFileName='"${!machine_truststore}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		sed -i -n -e '/^CustomTrustKeyStorePassPhrase=/!p' -e '$aCustomTrustKeyStorePassPhrase='"${!machine_truststorepw}" ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!machine_name}
		
	done

	# Replace nodemanager.properties with the prepared copy for the first machine
	# On second machine, this step needs to be done manually
	firstmachine=`echo $machines | cut -d"," -f1`_Name
	cp -p ${domainroot}/${domain_name}/nodemanager/nodemanager.properties_${!firstmachine} ${domainroot}/${domain_name}/nodemanager/nodemanager.properties

	# Populate nm_password.properties
	echo "username=${domain_username}" > ${domainroot}/${domain_name}/config/nodemanager/nm_password.properties
	echo "password=${domain_password}" >> ${domainroot}/${domain_name}/config/nodemanager/nm_password.properties
}

update_env_sh() {
	echo "Backing up setDomainEnv.sh"
	cp -p ${domainroot}/${domain_name}/bin/setDomainEnv.sh ${domainroot}/${domain_name}/bin/setDomainEnv.sh_`date +%Y%m%d%H%M%S`
	echo "Updating setDomainEnv.sh to disable derby"
	sed -i '/"${DERBY_FLAG}" = ""/i export DERBY_FLAG=false' ${domainroot}/${domain_name}/bin/setDomainEnv.sh
	sed -i '/"${DERBY_FLAG}" = ""/I,+5 d' ${domainroot}/${domain_name}/bin/setDomainEnv.sh

}

create_boot_props() {
	echo "Creating boot.properties"
	mkdir -p ${domainroot}/${domain_name}/servers/${admin_Name}/security
	echo "username=${domain_username}" > ${domainroot}/${domain_name}/servers/${admin_Name}/security/boot.properties
	echo "password=${domain_password}" >> ${domainroot}/${domain_name}/servers/${admin_Name}/security/boot.properties
}

restart_node_manager() {
	echo "Stopping node manager"
	nohup ${domainroot}/${domain_name}/bin/stopNodeManager.sh & > /dev/null 2>&1
	echo "Starting node manager"
	nohup ${domainroot}/${domain_name}/bin/startNodeManager.sh & > /dev/null 2>&1
}

populate_py_scripts () {
	ccbabin=${domainroot}/${domain_name}/bin/ccba
	echo "Populating stop start scripts, all custom "
	mkdir -p $ccbabin
	
	firstmachine=`echo $machines | cut -d"," -f1`
	firstmachine_name=${firstmachine}_Name
	firstmachine_nm_secure=${firstmachine}_nm_secure
	firstmachine_nm_address=${firstmachine}_nm_address
	firstmachine_nm_port=${firstmachine}_nm_port
	firstmachine_nm_type=${firstmachine}_nm_type
	
	echo "Preparing ctrlAdm.py, $ccbabin/ctrlAdm.py"
	cp -p $BASEDIR/ctrlAdm.py.template $ccbabin/ctrlAdm.py
	sed -i "s|DOMAINROOT|${domainroot}|g" $ccbabin/ctrlAdm.py
	sed -i "s|DOMAIN_NAME|${domain_name}|g" $ccbabin/ctrlAdm.py
	sed -i "s|ADMIN_NAME|${admin_Name}|g" $ccbabin/ctrlAdm.py
	sed -i "s|ADMIN_ADDRESS|${admin_address}|g" $ccbabin/ctrlAdm.py
	sed -i "s|ADMIN_ADMINPORT|${admin_adminport}|g" $ccbabin/ctrlAdm.py
	sed -i "s|M_NM_ADDRESS|${!firstmachine_nm_address}|g" $ccbabin/ctrlAdm.py
	sed -i "s|M_NM_PORT|${!firstmachine_nm_port}|g" $ccbabin/ctrlAdm.py
	sed -i "s|M_NM_TYPE|${!firstmachine_nm_type}|g" $ccbabin/ctrlAdm.py

	for machine in `echo $machines | sed 's/,/ /g'`
	do
		machine_name=${machine}_Name
		machine_nm_secure=${machine}_nm_secure
		machine_nm_address=${machine}_nm_address
		machine_nm_port=${machine}_nm_port
		machine_nm_type=${machine}_nm_type
		
		echo "Preparing ctrlMgd.py for each machine, $ccbabin/ctrlMgd.py_${!machine_name} "
		cp -p $BASEDIR/ctrlMgd.py.template $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|DOMAINROOT|${domainroot}|g" $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|DOMAIN_NAME|${domain_name}|g" $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|ADMIN_NAME|${admin_Name}|g" $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|ADMIN_ADDRESS|${admin_address}|g" $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|ADMIN_ADMINPORT|${admin_adminport}|g" $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|M_NM_ADDRESS|${!machine_nm_address}|g" $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|M_NM_PORT|${!machine_nm_port}|g" $ccbabin/ctrlMgd.py_${!machine_name}
		sed -i "s|M_NM_TYPE|${!machine_nm_type}|g" $ccbabin/ctrlMgd.py_${!machine_name}	
	done

	echo "Rename ctrlMgd.py_${!firstmachine_name} to $ccbabin/ctrlMgd.py"
	echo "If there are multiple machines, this script needs to be renamed manually on each"
	cp -p $ccbabin/ctrlMgd.py_${!firstmachine_name} $ccbabin/ctrlMgd.py
}

populate_sh_scripts () {
	ccbabin=${domainroot}/${domain_name}/bin/ccba
	mkdir -p $ccbabin
	echo "Populating custom shell scripts to $ccbabin"

	echo ". ${domainroot}/${domain_name}/bin/setDomainEnv.sh" > $ccbabin/startNM.sh
	echo "nohup ${domainroot}/${domain_name}/bin/startNodeManager.sh &" >> $ccbabin/startNM.sh
	echo ". ${domainroot}/${domain_name}/bin/setDomainEnv.sh" > $ccbabin/stopNM.sh
	echo "${domainroot}/${domain_name}/bin/stopNodeManager.sh" >> $ccbabin/stopNM.sh

	echo ". ${domainroot}/${domain_name}/bin/setDomainEnv.sh" > $ccbabin/startAdm.sh
	echo "java -Dweblogic.security.TrustKeyStore=CustomTrust -Dweblogic.security.CustomTrustKeyStoreType=JKS -Dweblogic.security.CustomTrustKeyStoreFileName=${admin_TrustStore} weblogic.WLST $ccbabin/ctrlAdm.py start ${admin_Name}" >> $ccbabin/startAdm.sh
	echo ". ${domainroot}/${domain_name}/bin/setDomainEnv.sh" > $ccbabin/stopAdm.sh
	echo "java -Dweblogic.security.TrustKeyStore=CustomTrust -Dweblogic.security.CustomTrustKeyStoreType=JKS -Dweblogic.security.CustomTrustKeyStoreFileName=${admin_TrustStore} weblogic.WLST $ccbabin/ctrlAdm.py stop ${admin_Name}" >> $ccbabin/stopAdm.sh
	echo ". ${domainroot}/${domain_name}/bin/setDomainEnv.sh" > $ccbabin/killAdm.sh
	echo "java -Dweblogic.security.TrustKeyStore=CustomTrust -Dweblogic.security.CustomTrustKeyStoreType=JKS -Dweblogic.security.CustomTrustKeyStoreFileName=${admin_TrustStore} weblogic.WLST $ccbabin/ctrlAdm.py kill ${admin_Name}" >> $ccbabin/killAdm.sh

	for managedserver in `echo $managedservers | sed 's/,/ /g'`
	do
		ms_name=${managedserver}_Name
		ms_truststore=${managedserver}_TrustStore
		echo ". ${domainroot}/${domain_name}/bin/setDomainEnv.sh" > $ccbabin/startMgd_${!ms_name}.sh
		echo "java -Dweblogic.security.TrustKeyStore=CustomTrust -Dweblogic.security.CustomTrustKeyStoreType=JKS -Dweblogic.security.CustomTrustKeyStoreFileName=${!ms_truststore} weblogic.WLST $ccbabin/ctrlMgd.py start ${!ms_name}" >> $ccbabin/startMgd_${!ms_name}.sh
		echo ". ${domainroot}/${domain_name}/bin/setDomainEnv.sh" > $ccbabin/stopMgd_${!ms_name}.sh
		echo "java -Dweblogic.security.TrustKeyStore=CustomTrust -Dweblogic.security.CustomTrustKeyStoreType=JKS -Dweblogic.security.CustomTrustKeyStoreFileName=${!ms_truststore} weblogic.WLST $ccbabin/ctrlMgd.py stop ${!ms_name}" >> $ccbabin/stopMgd_${!ms_name}.sh
	done
	chmod 750 $ccbabin/*
}

restart_kill_admin() {
	echo "Killing Admin"
	#${domainroot}/${domain_name}/bin/ccba/killAdm.sh
	adminpid=`ps -ef | grep ${domain_name} | grep java | grep weblogic.Server | awk '{print $2}'`
	kill -9 $adminpid
	sleep 3
	echo "Starting Admin"
	${domainroot}/${domain_name}/bin/ccba/startAdm.sh
}

restart_admin() {
	echo "Stopping Admin"
	${domainroot}/${domain_name}/bin/ccba/stopAdm.sh
	sleep 3
	echo "Starting Admin"
	${domainroot}/${domain_name}/bin/ccba/startAdm.sh
}

execute_nm_boot_props_py() {
	echo "Running nmGenBootStartupProps.py "
	echo "If there are additional machines, this needs to be run on each"
	echo "java -Dweblogic.security.TrustKeyStore=CustomTrust -Dweblogic.security.CustomTrustKeyStoreType=JKS -Dweblogic.security.CustomTrustKeyStoreFileName=${admin_TrustStore} weblogic.WLST nmGenBootStartupProps.py"
	. ${domainroot}/${domain_name}/bin/setDomainEnv.sh
	java -Dweblogic.security.TrustKeyStore=CustomTrust -Dweblogic.security.CustomTrustKeyStoreType=JKS -Dweblogic.security.CustomTrustKeyStoreFileName=${admin_TrustStore} weblogic.WLST $BASEDIR/nmGenBootStartupProps.py
}

tar_domain() {
	timestamp=`date +%Y%m%d%H%M%S`
	echo "Tarring up the domain for transfer to other machines if necessary, location below"
	echo "============"
	echo "${domainroot}/${domain_name}_$timestamp.tar"
	echo "============"
	tar -cf ${domainroot}/${domain_name}_$timestamp.tar ${domainroot}/${domain_name}

}


# Main
BASEDIR=`pwd`

check_prereq
source_props
wls_domain_creator
prepare_nm_config
update_env_sh
create_boot_props
restart_node_manager
populate_py_scripts
populate_sh_scripts
restart_kill_admin
execute_nm_boot_props_py
restart_node_manager
restart_admin
tar_domain

exit 0