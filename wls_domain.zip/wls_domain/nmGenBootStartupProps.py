import os
import sys
from os.path import exists
from sys import argv

def get_script_path():
	return os.path.dirname(os.path.realpath(sys.argv[0]))
def parsefile():
	propfile = get_script_path()+"/domain.properties"
	if exists(propfile):
		global fo
		fo = open(propfile, 'r+')
    		lines = fo.readlines()
    		for line in lines:
        		#print line.rstrip()
        		if "=" in line:
        			line = line.rstrip()
        			key = line.split('=')[0]
        			value = line.split('=')[1]
        			_dict[key]=value
        
        		
def printdomain():
	print '------------------------------'
	print "Properties Information"
	print '------------------------------'
	for key, val in _dict.iteritems():
		print key,"=>",val
def export_properties():
	global _dict
	global mwhome
	global wlshome
	global templatever
	global domainroot
#	global approot
	global domainName
	global domain_username
	global domain_password
	global adminName
	global adminPort
	global adminAddress
	global adminPortSSL
	global adminAdminPort
	global adminMachine
	global machines
	global servers
	global allservers
	global clusters
	mwhome = _dict.get('mwhome')
	wlshome = _dict.get('wlshome')
	templatever = _dict.get('templatever')
	domainroot = _dict.get('domainroot')
	domainName = _dict.get('domain_name')
	domain_username = _dict.get('domain_username')
	domain_password = _dict.get('domain_password')
	adminName = _dict.get("admin_Name")
	adminPort = _dict.get("admin_port")
	adminAddress = _dict.get("admin_address")
	adminPortSSL = _dict.get("admin_sslport")
	adminAdminPort = _dict.get("admin_adminport")
	machines = _dict.get("machines").split(',')
	servers = _dict.get("managedservers").split(',')
	allservers = [x for x in servers]
	allservers.append("admin")
	clusters = _dict.get("clusters").split(',')

def connect_online():
	try:
		global managementurl
		managementurl = "t3s://"+adminAddress+":"+adminAdminPort
		print "\nConnecting to AdminServer with managementurl",managementurl
		connect(domain_username,domain_password,managementurl)
		print "\nSuccessfully Connected to AdminServer!!"
		
	except:
		print "ERROR: Unable to Connect to AdminServer"
		sys.exit(2)

def acquire_edit_session():
	edit()
	startEdit()
def save_activate_session():
	save()
	activate()


# Set up domain level node manager user and password
def setup_nm_cred():
	acquire_edit_session()
	print "\nSetting up node manager credential at the domain level "
	cd('/')
	cd('SecurityConfiguration/'+domainName)
	set('NodeManagerUsername',domain_username)
	set('NodeManagerPassword',domain_password)
	save_activate_session()

# Generate startup.properties of the admin server for node manager
# This step is only required for admin server as it's not automatically done (Doc ID 1360125.1)
# For managed servers, this step is automcatically done when started by node manager
def gen_nm_boot_props():
	acquire_edit_session()
	print "\nGenerating startup.properties for admin server "+adminName
	nmGenBootStartupProps(adminName)
	save_activate_session()

if __name__ != "__main__":
	_dict={};
	parsefile()
	export_properties()
	connect_online()
	gen_nm_boot_props()
	print "End of Script Execution << \nGood Bye!"
	sys.exit(0)
	
if __name__ == "__main__":
	print "This script has to be executed with weblogic WLST"