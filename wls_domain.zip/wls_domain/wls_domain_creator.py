import os
import sys
from os.path import exists
from sys import argv

def get_script_path():
	return os.path.dirname(os.path.realpath(sys.argv[0]))
def parsefile():
	propfile = get_script_path()+"/domain.properties"
	if exists(propfile):
		global fo
		fo = open(propfile, 'r+')
    		lines = fo.readlines()
    		for line in lines:
        		#print line.rstrip()
        		if "=" in line:
        			line = line.rstrip()
        			key = line.split('=')[0]
        			value = line.split('=')[1]
        			_dict[key]=value
        
        		
def printdomain():
	print '------------------------------'
	print "Properties Information"
	print '------------------------------'
	for key, val in _dict.iteritems():
		print key,"=>",val
def export_properties():
	global _dict
	global mwhome
	global wlshome
	global templatever
	global domainroot
	global domainName
	global domain_username
	global domain_password
	global console_context
	global adminName
	global adminPort
	global adminAddress
	global adminPortSSL
	global adminAdminPort
	global adminMachine
	global machines
	global servers
	global allservers
	global clusters
	mwhome = _dict.get('mwhome')
	wlshome = _dict.get('wlshome')
	templatever = _dict.get('templatever')
	domainroot = _dict.get('domainroot')
	domainName = _dict.get('domain_name')
	domain_username = _dict.get('domain_username')
	domain_password = _dict.get('domain_password')
	console_context = _dict.get('console_context')
	adminName = _dict.get("admin_Name")
	adminPort = _dict.get("admin_port")
	adminAddress = _dict.get("admin_address")
	adminPortSSL = _dict.get("admin_sslport")
	adminAdminPort = _dict.get("admin_adminport")
	machines = _dict.get("machines").split(',')
	servers = _dict.get("managedservers").split(',')
	allservers = [x for x in servers]
	allservers.append("admin")
	clusters = _dict.get("clusters").split(',')
def read_template():
	# Select and load the template. Versions > 12.2
	try:
		selectTemplate("Basic WebLogic Server Domain",templatever)
		loadTemplates()
	except:
		print "Error Reading the Template",wlstemplate
		print "Dumpstack: \n -------------- \n",dumpStack()
		sys.exit(2)
def create_machine():
	try:
		for machine in machines:
			cd('/')
			print "Creating a New Machine with the following Configuration"
			mn = create(machine,'Machine')
			machine_name=_dict.get(machine+'_Name')
			
			nm_type=_dict.get(machine+'_nm_type')
			nm_address=_dict.get(machine+'_nm_address')
			nm_port=_dict.get(machine+'_nm_port')
			if (machine_name != ""):
				print "\tMachine Name",machine_name
				mn.setName(machine_name)
				cd('Machine/'+machine_name)
				nm = create(machine_name,'NodeManager')
				nm.setNMType(nm_type)
				nm.setListenAddress(nm_address)
				nm.setListenPort(int(nm_port))
			else:
				print "No machine Name mentioned for",machine
	except:
		print "Creating Machine failed",machine
		print "Dumpstack: \n -------------- \n",dumpStack()
		sys.exit(2)
def create_admin():
	try:
		print "\nCreating AdminServer with the following Configuraiton"
		cd('/Security/base_domain/User/' + domain_username)
		cmo.setPassword(domain_password)
		cd('/Server/AdminServer')
		cmo.setName(adminName)
		cmo.setListenPort(int(adminPort))
		cmo.setListenAddress(adminAddress)
		
		print "\tAdminServer ListenPort:",adminPort
		print "\tAdminServer Listenaddress:",adminAddress
		print "\tAdminServer SSLListenPort:",adminPortSSL
		# create('AdminServer','SSL')
		# cd('SSL/AdminServer')
		# set('Enabled', 'True')
		# set('ListenPort', int(adminPortSSL))
	except:
		print "Error while creating AdminServer"
		print "Dumpstack: \n -------------- \n",dumpStack()
def create_managedserver():
	try:
		cd ('/')
		for server in servers:
			MSN = _dict.get(server+'_Name')
			MSP = _dict.get(server+'_port')
			MSA = _dict.get(server+'_address')
			MSM = _dict.get(server+'_machine')
			print "\nCreating A New Managed Server with following Configuration"
			print "\tServerName:",MSN
			print "\tServer ListenPort:",MSP
			print "\tServer ListenAddress:",MSA
			sobj = create(MSN,'Server')
			sobj.setName(MSN)
			sobj.setListenPort(int(MSP))
			sobj.setListenAddress(MSA)
			#sobj.setMachine(MSM)
	except:
		print "Error While Creating ManagedServer",server
		print "Dumpstack: \n -------------- \n",dumpStack()
		
def create_clusters():
	try:
		cd ('/')
		for cluster in clusters:
			CN = _dict.get(cluster+'_Name')
			cobj = create(CN,'Cluster')
			print "\nCreating a New Cluster with the following Configuration"
			print "\tClusterName",CN
	except:
		print "Error while Creating Cluster",cluster
		print "Dumpstack: \n -------------- \n",dumpStack()
		sys.exit(2)
def commit_writedomain():
	try:
		# If the domain already exists, overwrite the domain
		setOption('OverwriteDomain', 'true')
		setOption('ServerStartMode','prod')
#		setOption('AppDir', approot + '/' + domainName)
		writeDomain(domainroot + '/' + domainName)
		closeTemplate()
	
	except:
		print "ERROR: commit_writedomain Failed"
		print "Dumpstack: \n -------------- \n",dumpStack()
		undo('false','y')
		stopEdit()
		exit()
def print_withformat(title):
	print "\n-----------------------------------------------------\n",title,"\n-----------------------------------------------------"
def print_somelines():
	print "-----------------------------------------------------"
def print_domainsummary():
	print "DomainName:",domainName
	print "DomainUserName:",domain_username
	print "DomainPassword: ****************"
	print "DomainDirectory:",domainroot
#	print "ApplicationRoot:",approot
def start_AdminServer():
	try:
		global managementurl
		managementurl = "t3://"+adminAddress+":"+adminPort
		global AdminServerDir
		AdminServerDir = domainroot+"/"+domainName+"/servers/"+adminName
		global AdminServerLogDir
		AdminServerLog = AdminServerDir+"/logs/"+adminName+".log"
		global DomainDir
		DomainDir = domainroot+"/"+domainName
		
		print_somelines()
		print "\nStarting Server with following Params"
		print_somelines()
		print "DomainDir",DomainDir
		print "managementurl",managementurl
		print_somelines()
		print "\nRedirecting Startup Logs to",AdminServerLog
		startServer(adminName,domainName,managementurl,domain_username,domain_password,DomainDir,'true',60000,serverLog=AdminServerLog)
		print "AdminServer has been successfully Started"
	except:
		print "ERROR: Unable to Start AdminServer"
		print "Dumpstack: \n -------------- \n",dumpStack()
def connect_online():
	try:
		global managementurl
		managementurl = "t3://"+adminAddress+":"+adminPort
		print "\nConnecting to AdminServer with managementurl",managementurl
		connect(domain_username,domain_password,managementurl)
		print "\nSuccessfully Connected to AdminServer!!"
		
	except:
		print "ERROR: Unable to Connect to AdminServer"
		sys.exit(2)
def store_user_config():
	try:
		print "Trying to generate user config files"
		storeUserConfig(DomainDir+'/config/admin.cfg',DomainDir+'/config/admin.key')
		print "\nSuccessfully generated user config files"
	except:
		print "ERROR: Unable to store user config"
		sys.exit(2)

def acquire_edit_session():
	edit()
	startEdit()
def save_activate_session():
	save()
	activate()
def Enable_wlst_log_redirection():
	#wlst output redirect to a logfile
	redirect('./wlst_execution.log','false')
def Stop_wlst_log_redirection():
	stopRedirect()
def map_machines():
	#try:
	acquire_edit_session()
	for machine in machines:
		 print "Starting to map resources to the machine ",machine
		 # set up node manager username password to be the same as weblogic's
		 machine_name=_dict.get(machine+'_Name')
		 cd('/')
		 cd('Machines/'+machine_name+'/NodeManager/'+machine_name)
		 set('UserName', domain_username)
		 set('Password', domain_password)
		 
		 instances = _dict.get(machine+"_instances")
		 #print "INST",instances
		 if len(instances) > 1:
		 	instances = instances.split(',')
		 	for instance in instances:
		 		if instance == "admin":
		 			instname = adminName
		 		else:
		 			instname = _dict.get(instance+"_Name")
		 		#print "What is the instname",instname
		 		cd ('/Servers/'+instname)
		 		#print "WHARE AM I",pwd()
		 		machine_name=_dict.get(machine+'_Name')
		 		mbean_name='/Machines/'+machine_name
		 		#print "What is Machine MBEAN",mbean_name
		 		cmo.setMachine(getMBean(mbean_name))
		 else:
				instname = _dict.get(instances+"_Name")
		 		#print "What is the instname",instname
		 		cd ('/Servers/'+instname)
		 		#print "WHARE AM I",pwd()
		 		machine_name=_dict.get(machine+'_Name')
		 		mbean_name='/Machines/'+machine_name
				cmo.setMachine(getMBean(mbean_name))
	save_activate_session()
def map_clusters():
	#try:
	acquire_edit_session()
	for cluster in clusters:
		cd('/')
		cluster_name=_dict.get(cluster+'_Name')
		print "\nSetting Secure replication for the cluster ",cluster
		cd('/Clusters/'+cluster_name)
		set('SecureReplicationEnabled', 'true')
		cd('/')
		print "\nStarting to map resources to the cluster ",cluster
		members = _dict.get(cluster+"_members")
		#print "members",members
		if len(members) > 1:
			members = members.split(',')
			for member in members:
				if member == "admin":
					membername = adminName
				else:
					membername = _dict.get(member+"_Name")
				#print "What is the memberName",membername
				cd ('/Servers/'+membername)
				#print "WHARE AM I",pwd()
				cluster_name=_dict.get(cluster+'_Name')
				mbean_name='/Clusters/'+cluster_name
				#print "What is Cluster MBEAN",mbean_name
				cmo.setCluster(getMBean(mbean_name))
		else:
				membername = _dict.get(member+"_Name")
				#print "What is the memberName",membername
				cd ('/Servers/'+membername)
				#print "WHARE AM I",pwd()
				cluster_name=_dict.get(cluster+'_Name')
				mbean_name='../../Clusters/'+cluster_name
				cmo.setCluster(getMBean(mbean_name))	
	save_activate_session()
	#except:
		#print "Machine Creation Failed"

# Enable SSL for both admin and managed servers
def enable_ssl():
	acquire_edit_session()
	for server in allservers:
		cd('/')
		servername = _dict.get(server+'_Name')
		print "\nStarting to enable ssl for the managed server ",servername
		ssl_port = _dict.get(server+'_sslport')
		admin_port = _dict.get(server+'_adminport')
		keystore = _dict.get(server+'_KeyStore')
		keystore_pw = _dict.get(server+'_KeyStorePW')
		truststore = _dict.get(server+'_TrustStore')
		truststore_pw = _dict.get(server+'_TrustStorePW')
		private_key_alias = _dict.get(server+'_PrivateKeyAlias')
		private_key_pw = _dict.get(server+'_PrivateKeyPW')

		cd('/Servers/'+servername)
		set('KeyStores','CustomIdentityAndCustomTrust')
		set('CustomIdentityKeyStoreFileName',keystore)
		set('CustomIdentityKeyStoreType','JKS')
		set('CustomIdentityKeyStorePassPhrase',keystore_pw)
		set('CustomTrustKeyStoreFileName',truststore)
		set('CustomTrustKeyStoreType','JKS')
		set('CustomTrustKeyStorePassPhrase', truststore_pw)
		set('AdministrationPort', admin_port)
		
		cd('SSL/'+servername)
		set('ServerPrivateKeyAlias', private_key_alias)
		set('ServerPrivateKeyPassPhrase', private_key_pw)
		set('ListenPort', ssl_port)
		set('Enabled', 'true')
	cd('/')
	set('AdministrationPortEnabled', 'true')
	set('ConsoleContextPath', console_context)
	save_activate_session()

# Change log rotation to be by time (midnight daily) and keep 60 days,
# same for http access log, and disable domain log
def setup_logging():
	acquire_edit_session()
	for server in allservers:
		cd('/')
		servername = _dict.get(server+'_Name')
		print "\nSetting up logging for ",servername
		cd('Servers/'+servername+'/Log/'+servername)
		set('RotationType', 'byTime')
		set('FileCount', '60')
		set('RedirectStderrToServerLogEnabled', 'true')
		set('RedirectStdoutToServerLogEnabled', 'true')
		set('DomainLogBroadcastSeverity', 'Off')
		
		cd('/Servers/'+servername+'/WebServer/'+servername+'/WebServerLog/'+servername)
		set('RotationType', 'byTime')
		set('FileCount', '60')
	save_activate_session()

# Add JVM arguments to Configuration -> Server Start
# These will be picked up by node manager
def setup_arguments():
	acquire_edit_session()
	for server in allservers:
		cd('/')
		servername = _dict.get(server+'_Name')
		serverargs = str(_dict.get(server+'_jvm')).strip('\"')
		print "\nSetting up jvm arguments for ",servername
		cd('Servers/'+servername+'/ServerStart/'+servername)
		set('Arguments',serverargs)
	save_activate_session()

# Disable auto restart by node manager
def disable_auto_restart():
	acquire_edit_session()
	for server in allservers:
		cd('/')
		servername = _dict.get(server+'_Name')
		serverargs = str(_dict.get(server+'_jvm')).strip('\"')
		print "\nDisabling auto restart by node manager ",servername
		cd('Servers/'+servername)
		set('AutoRestart','false')
	save_activate_session()

# Set up domain level node manager user and password
def setup_nm_cred():
	acquire_edit_session()
	print "\nSetting up node manager credential at the domain level "
	cd('/')
	cd('SecurityConfiguration/'+domainName)
	set('NodeManagerUsername',domain_username)
	set('NodeManagerPassword',domain_password)
	save_activate_session()

# Generate startup.properties of the admin server for node manager
# This step is only required for admin server as it's not automatically done (Doc ID 1360125.1)
# For managed servers, this step is automcatically done when started by node manager
# def gen_nm_boot_props():
	# acquire_edit_session()
	# print "\nGenerating startup.properties for admin server "+adminName
	# nmGenBootStartupProps(adminName)
	# save_activate_session()

if __name__ != "__main__":
	_dict={};
	Enable_wlst_log_redirection()
	print "Start of the script Execution >>"
	print "Parsing the properties file..."
	parsefile()
	print "Exporting the Properties to variables.."
	export_properties()
	print "Creating Domain from Domain Template..."
	read_template()
	print_withformat("Creating Machines")
	create_machine()
	print_somelines()
	print_withformat("Creating AdminServer")
	create_admin()
	print_somelines()
	print_withformat("Creating ManagedServers")
	create_managedserver()
	print_somelines()
	print_withformat("Creating Clusters")
	create_clusters()
	print_somelines()
	print "\nCommit and Saving the Domain"
	commit_writedomain()
	print_withformat("Domain Summary")
	print_domainsummary()
	print_somelines()
	print("Starting the AdminServer")
	start_AdminServer()
	connect_online()
	store_user_config()
	map_machines()
	map_clusters()
	#enable_ssl()
	setup_logging()
	setup_arguments()
	disable_auto_restart()
	setup_nm_cred()
	enable_ssl()
	print "End of Script Execution << \nGood Bye!"
	Stop_wlst_log_redirection()
	sys.exit(0)
if __name__ == "__main__":
	print "This script has to be executed with weblogic WLST"